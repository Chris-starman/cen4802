<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Display Input</title>
</head>
<body>
<h2>Your Input Result</h2>

<%
    // Retrieve the value from the form input named "username"
    String name = request.getParameter("username");
%>

<!-- Print the value using JSP expression tag -->
<p>Hello, <strong><%= name %></strong>!</p>

</body>
</html>